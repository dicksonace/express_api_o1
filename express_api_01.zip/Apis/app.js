const express = require("express");
const bodyParser = require("body-parser");
const app = express();

const usersRoute = require("./routers/users-router");

app.use(bodyParser.json());

app.use("/api/users", usersRoute);

app.listen(3000);

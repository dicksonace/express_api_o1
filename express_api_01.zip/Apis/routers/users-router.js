const express = require("express");
const router = express.Router();

const usersController = require("../controllers/users-controller");

router.get("/", usersController.getUsers);
router.post("/add", usersController.createUser);
router.patch("/update/:uid", usersController.updateUser);
router.delete("/delete/:uid", usersController.deleteUser);

module.exports = router;

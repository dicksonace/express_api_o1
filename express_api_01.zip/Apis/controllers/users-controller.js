let DUMMY_USERS = [];

const getUsers = (req, res, next) => {
  let users = DUMMY_USERS.map((user) => user);

  if (users.length === 0) {
    return next(res.json({ message: "No Users yet" }));
  }
  res.json({ users });
};

const createUser = (req, res, next) => {
  const { name, username, country } = req.body;

  const createdUser = {
    id: Math.random().toString(),
    name,
    username,
    country,
  };
  DUMMY_USERS.push(createdUser);
  res.json({ createdUser });
};

const updateUser = (req, res, next) => {
  const userId = req.params.uid;
  const { name } = req.body;

  const user = DUMMY_USERS.find((user) => user.id === userId);

  if (!user) {
    return next(res.json({ message: "No User found" }));
  }

  user.name = name;

  res.json({ message: "users updated!" });
};

const deleteUser = (req, res, next) => {
  const userId = req.params.uid;

  const user = DUMMY_USERS.find((user) => user.id === userId);

  if (!user) {
    return next(res.json({ message: "User Not found", userId }));
  }

  DUMMY_USERS = DUMMY_USERS.filter((user) => user.id !== userId);

  res.json({ message: "User Deleted" });
};

exports.getUsers = getUsers;
exports.createUser = createUser;
exports.updateUser = updateUser;
exports.deleteUser = deleteUser;
